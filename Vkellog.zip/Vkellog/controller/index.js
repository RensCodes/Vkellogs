const main = document.getElementById('card-3')
const product = document.getElementById('product')
const recipe = document.getElementById('card-4')
const remain = document.getElementById('card-1')
const contact = document.getElementById('contactForm');
import data from "./data.json" assert {type : 'json'}

const Cereal = data.Cereal
const Resepe = data.Recipe
const Data3 = Cereal.slice(0, 4)
const Recips = Resepe.slice(0,2)



// controller
const Main = () => {
    Data3.forEach(item => {
        const container = document.querySelector('.card-3');
        const card = document.createElement('div');
        card.classList.add('card');
        card.innerHTML = `
            <div class="card-header">
                <img src="${item.image}" alt="${item.nama}">
            </div>
            <div class="card-body">
                <h5>${item.nama}</h5>
                <p>Rp. ${item.harga}</p>
            </div>
        `;
        container.appendChild(card);
    });
}

const Product = () => {
    Cereal.forEach(item => {
        const container = document.querySelector('.product');
        const card = document.createElement('div');
        card.classList.add('card');
        card.innerHTML = `
            <div class="card-header">
                <img src="${item.image}" alt="${item.nama}">
            </div>
            <div class="card-body">
                <h5>${item.nama}</h5>
                <p>Rp. ${item.harga}</p>
            </div>
        `;
        container.appendChild(card);
    });
}

const Resep = () => {
    Resepe.forEach(item => {
        const container = document.querySelector('.card-4');
        const card = document.createElement('div');
        card.classList.add('card');
        card.innerHTML = `
            <div class="card-header">
                <img src="${item.image}" alt="${item.nama}">
            </div>
            <div class="card-body">
                <h5>${item.nama}</h5>
                <p>${item.serve}</p>
            </div>
        `;
        container.appendChild(card);
    });
}

const Recip = () => {
    Recips.forEach(item => {
        const container = document.querySelector('.card-1');
        const card = document.createElement('div');
        card.classList.add('card');
        card.innerHTML = `
            <div class="card-header">
                <img src="${item.image}" alt="${item.nama}">
            </div>
            <div class="card-body">
                <h5>${item.nama}</h5>
                <p>${item.serve}</p>
            </div>
        `;
        container.appendChild(card);
    });
}

const formContact = () => {
    document.getElementById('contactForm').addEventListener('submit', function(event) {
        event.preventDefault();

        var firstName = document.getElementById('FirstName').value;
        var LastName = document.getElementById('LastName').value;
        var email = document.getElementById('PhoneNum').value
        var pesan = document.getElementById('message').value

        console.log(firstName, LastName, email, pesan);
    })
}


// Route

if (!main) {
    console.log("data Tidak ada")
}else{
    Main(Data3)
}

if(!recipe){
    console.log("data Tidak ada Yaa")
}else{
    Resep(Resepe)
}

if(!remain){
    console.log("Data Tidak Ditemukan")
}else{
    Recip(Recips)
}
if(!contact){
    console.log('Data menghilang');
}else{
    formContact()
}
if(!product) {
    console.log('data Gada')
}else{
    Product(Cereal)
}



